# cmake-scripts
Collection of CMake scripts to ease development
