# ASSETS
Place your assets and game data in this folder. The +GD build target will then package them for you. 

**Don't forget to credit original authors**.